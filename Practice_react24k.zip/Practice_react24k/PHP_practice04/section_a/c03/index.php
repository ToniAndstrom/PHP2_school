<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <link href="../../css/styles.css" rel="stylesheet">
  <title>Chapter 3: Functions</title>
</head>

<body>
  <a href="../../index.php">Programming PHP</a>
  <h2>Chapter 3: Functions</h2>
  <table>
    <tr>

      <th>Title</th>
      <th>Filename</th>
    </tr>
    <tr>

      <td class="title">Basic Functions</td>
      <td class="link"><a href="basicfunctions.php">basic-functions.php</a></td>
    </tr>

  </table>
</body>

</html>
    <footer>&copy; <?php echo date('Y')?></footer>
  </body>
</html>
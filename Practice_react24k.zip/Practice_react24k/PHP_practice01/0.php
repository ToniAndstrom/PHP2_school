<?php include "functions.php"; ?>
<?php include "includes/header.php"; ?>

<section class="content">

  <aside class="col-xs-4">

    <?php Navigation(); ?>

  </aside>
  <!--SIDEBAR-->


  <article class="main-content col-xs-8">
    <html>

    <head>
      <title>PHP Test</title>
    </head>

    <body>
    <?php
    /*
    Step 1:  Write "Hello PHP"
    */
    ?>
    </body>

    </html>
  </article>
  <!--MAIN CONTENT-->

  <?php include "includes/footer.php"; ?>
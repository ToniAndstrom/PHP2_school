<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <link href="../../css/styles.css" rel="stylesheet">
  <title>Programming PHP</title>
</head>

<body>
  <a href="../../index.php">Programming PHP</a>
  <h2>Objects and Classes</h2>
  <table>
    <tr>
      <th>Title</th>
      <th>Filename</th>
    </tr>
    <tr>
      <td class="title">Using Constructors in Classes</td>
      <td class="link"><a href="constructor-methods.php">constructor-methods.php</a></td>
    </tr>

  </table>
</body>

</html>
<!DOCTYPE html>
<html>

<head>
  <title>PHP &amp; MySQL</title>
  <link rel="stylesheet" type="text/css" href="css/styles.css" />
</head>

<body>
  <h1 id="header">PHP &amp; MySQL</h1>

  <table>
    <tr>
      <td class="section">Section A: Basic Programming Instructions</td>
    </tr>

    <tr>
      <td><a href="section_a/c04/">PHP: Object Oriented Programming</a></td>
    </tr>


  </table>
</body>

</html>
<!DOCTYPE html>
<html>

<head>
  <title>PHP &amp; MySQL</title>
  <link rel="stylesheet" type="text/css" href="css/styles.css" />
</head>

<body>
  <h1 id="header">Programming PHP</h1>
  <h2>Practice makes you perfect :)</h2>
  <table>
    <tr>
      <td class="section">Section A: Basic Programming Instructions</td>
    </tr>

    <tr>
      <td><a href="section_b/c05/">Chapter 5: Built-In Functions</a></td>
    </tr>


  </table>
</body>

</html>
<?php
// Write PHP code here

?>
<?php include 'includes/header.php'; ?>

<h1>Best Sellers</h1>
//Write code here

<?php include 'includes/footer.php'; ?>
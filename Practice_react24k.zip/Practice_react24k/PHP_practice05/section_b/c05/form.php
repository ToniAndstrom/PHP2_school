<!DOCTYPE html>
<html>
  <body>
    <form action="welcome.php" method="post">
      Name: <input type="text" name="name" /><br />
      E-mail: <input type="text" name="email" /><br />
      <input type="submit" />
    </form>
  </body>
</html>

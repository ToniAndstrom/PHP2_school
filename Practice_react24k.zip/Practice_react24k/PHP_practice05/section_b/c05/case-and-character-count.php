<?php
$text = 'Home sweet home';
?>
<?php include 'includes/header.php'; ?>

<p>
  /** Write your code here */
</p>

<?php include 'includes/footer.php'; ?>
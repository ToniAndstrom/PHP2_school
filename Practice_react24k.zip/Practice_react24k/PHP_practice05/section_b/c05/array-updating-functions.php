<?php
// Write your code here

?>
<?php include 'includes/header.php'; ?>

<h1>Order</h1>

// Write your code here

<?php include 'includes/footer.php'; ?>
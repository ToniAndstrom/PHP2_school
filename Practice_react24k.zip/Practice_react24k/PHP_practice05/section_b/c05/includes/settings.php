<?php
define('SITE_NAME', 'Mountain Art Supplies');
define('ADMIN_EMAIL', 'admin@eg.link');
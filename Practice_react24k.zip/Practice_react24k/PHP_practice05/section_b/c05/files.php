<?php
$path = 'img/logo.png';
?>
<?php include 'includes/header.php'; ?>

// Write you PHP code here

<?php include 'includes/footer.php'; ?>